/*
 * Copyright (C) 2026, Hogeschool Rotterdam
 * All rights reserved.
 */

#include <stdint.h>

int main(void) {
    while (1) {
        // Simple delay loop
        volatile uint32_t i = 0;
        while (i < 500000) {
            i++;
        }
    }
}
