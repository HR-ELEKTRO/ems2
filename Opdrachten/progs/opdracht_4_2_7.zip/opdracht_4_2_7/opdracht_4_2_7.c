/*
 * Copyright (C) 2026, Hogeschool Rotterdam
 * All rights reserved.
 */

#include <fsl_gpio.h>
#include <fsl_port.h>

int main(void) {
    // Enable the clock for the GPIO and PORT peripherals
    CLOCK_EnableClock(kCLOCK_GatePORT3); 
    CLOCK_EnableClock(kCLOCK_GateGPIO3);

    // Release GPIO and PORT peripherals from reset.
    RESET_ReleasePeripheralReset(kGPIO3_RST_SHIFT_RSTn);
    RESET_ReleasePeripheralReset(kPORT3_RST_SHIFT_RSTn);

    // Define the GPIO pin configuration (Direction: Output, Initial State: High)
    gpio_pin_config_t led_config = {
        .pinDirection = kGPIO_DigitalOutput,
        .outputLogic = 1,
    };

    // Initialize the GPIO pin
    GPIO_PinInit(GPIO3, 0, &led_config);

    while (1) {
        GPIO_PinWrite(GPIO3, 0, 0);  // Turn on the LED
        // Simple delay loop
        for (volatile uint32_t i = 0; i < 500000; i++);
        GPIO_PinWrite(GPIO3, 0, 1);  // Turn off the LED
        // Simple delay loop
        for (volatile uint32_t i = 0; i < 500000; i++);
    }
}
